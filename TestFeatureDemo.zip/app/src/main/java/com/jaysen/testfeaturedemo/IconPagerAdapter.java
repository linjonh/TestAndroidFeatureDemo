package com.jaysen.testfeaturedemo;

/**
 * Created by liuj on 2016/2/22.
 *
 * PagerAdapter with icon
 */
public interface IconPagerAdapter {

    int getIcon(int pos);

    int getCount();
}
