package com.jaysen.testfeaturedemo;

import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    protected Button button;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        super.setContentView(R.layout.activity_main);
        SimplePagerTabLayout simplePagerTabLayout = (SimplePagerTabLayout) findViewById(R.id.challenge_tab_layout);
        ViewPager            viewPager            = (ViewPager) findViewById(R.id.challengeViewPager);
        viewPager.setAdapter(new ChallengeViewPagerAdapter(getSupportFragmentManager(), new String[]{"哈哈哈", "二按时方"}));

        simplePagerTabLayout.setViewPager(viewPager);

        ProgressBar progressBar = (ProgressBar) findViewById(R.id.progressBar);
//        LevelListDrawable levelListDrawable = (LevelListDrawable) getResources().getDrawable(
//                R.drawable.challenge_level_progress_drawable);
//        levelListDrawable.setLevel(10);
        LayerDrawable layerDrawable = (LayerDrawable) getResources().getDrawable(R.drawable.progress);
        progressBar.setProgressDrawable(layerDrawable);
        progressBar.setProgress(50);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        initView();

    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.button) {
            BlankDialogFragment.newInstance("", "").show(getSupportFragmentManager(), "dlg");
        }
    }

    private void initView() {
        button = (Button) findViewById(R.id.button);
        button.setOnClickListener(MainActivity.this);
    }
}
