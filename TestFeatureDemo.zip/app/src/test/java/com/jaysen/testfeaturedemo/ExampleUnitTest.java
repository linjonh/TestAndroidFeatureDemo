package com.jaysen.testfeaturedemo;

import org.junit.Test;

import java.text.DecimalFormat;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() throws Exception {
//        assertEquals(4, 2 + 2);
        long    val    = 1000;
        String parsed = parsePayment(val);
        System.out.println("parsedP: " + parsed);
    }

    /**
     * 格式化金额，只保留有效位
     * <p>
     * 例如：1.0-->1; 1.12-->1.12
     */
    public static String parsePayment(double payment) {
        DecimalFormat df = new DecimalFormat("#.##");
        return df.format(payment);
    }
}